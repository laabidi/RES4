#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget     *objet,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_play_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_instagram_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_facebook_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_twitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_skytravel_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
