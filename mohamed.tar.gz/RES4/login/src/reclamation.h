#include <gtk/gtk.h>

typedef struct
{

char cin[20];
char description[30];

}Reclamation;


