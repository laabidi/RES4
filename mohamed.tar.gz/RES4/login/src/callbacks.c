#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"
#include "reservation.h"










char usernam[50];
int verifier(char username [], char password [])
{
FILE*f;
int r;
int a=0;
char user[20],pass[20];
f=fopen("Users.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %d\n",user,pass,&r)!=EOF){
if((strcmp(username,user)==0) && (strcmp(password,pass)==0))
{a=r;}

}}
fclose(f);
return (a) ;
}
void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
memset (usernam, 0, sizeof (usernam));
        GtkWidget *input1,*input2, *output;
	GtkWidget *window1, *window4;
	int role=0;
	int a=0;
	char username[20], password[20];
        char erreure[50];
	output=lookup_widget(button,"label0");
	window1=lookup_widget(button,"window1");
	input1 = lookup_widget(button, "entry1");
	input2 = lookup_widget(button, "entry2");

	strcpy(username, gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(password, gtk_entry_get_text(GTK_ENTRY(input2)));
	role=verifier(username,password);
		if(role == 0)
		{
	        

                GdkColor color;
	        gdk_color_parse ("red", &color);
	        gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
	        strcpy(erreure,"Corrigé Votre Mote de Passe ou ID");
	        gtk_label_set_text(GTK_LABEL (output), erreure);



		}
		else if (role == 3)
		{
		gtk_widget_hide(window1);
		window1 = create_window4();
		gtk_widget_show (window1);
		}
		

		
}
		


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window3;

window1=lookup_widget(button,"window1");

gtk_widget_destroy(window1);
window3 = create_window3();
gtk_widget_show(window3);

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window1, *window2;

window1=lookup_widget(button,"window1");

gtk_widget_destroy(window1);
window2 = create_window2();
gtk_widget_show(window2);

}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *entry2;
entry2= lookup_widget(GTK_WIDGET(togglebutton),"entry2");
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
gtk_entry_set_visibility(GTK_ENTRY (entry2), TRUE);
else
gtk_entry_set_visibility (GTK_ENTRY (entry2), FALSE);

}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;

window2=lookup_widget(button,"window2");

gtk_widget_destroy(window2);
window1 = create_window1();
gtk_widget_show(window1);

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window3;

window3=lookup_widget(button,"window3");

gtk_widget_destroy(window3);
window1 = create_window1();
gtk_widget_show(window1);

}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window5;

window4=lookup_widget(button,"window4");

gtk_widget_destroy(window4);
window5 = create_window5();
gtk_widget_show(window5);
}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window6;

window4=lookup_widget(button,"window6");

gtk_widget_destroy(window6);
window6 = create_window6();
gtk_widget_show(window6);
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window7;

window4=lookup_widget(button,"window4");

gtk_widget_destroy(window4);
window7 = create_window7();
gtk_widget_show(window7);
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window4;

window4=lookup_widget(button,"window4");

gtk_widget_destroy(window4);
window1 = create_window1();
gtk_widget_show(window1);

}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window5;

window5=lookup_widget(button,"window5");

gtk_widget_destroy(window5);
window4 = create_window4();
gtk_widget_show(window4);


}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window6;

window6=lookup_widget(button,"window6");

gtk_widget_destroy(window6);
window4 = create_window4();
gtk_widget_show(window4);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window7;

window7=lookup_widget(button,"window7");

gtk_widget_destroy(window7);
window4 = create_window4();
gtk_widget_show(window4);
}


void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

reservation r;

GtkWidget *output,*input1,*input2,*input3, *input4,*input5;
GtkWidget *window5;

window5=lookup_widget(objet,"window5");

output=lookup_widget(objet,"label00");
input1=lookup_widget(objet,"comboboxentry1");
input2=lookup_widget(objet,"entry12");
input3=lookup_widget(objet,"entry16");
input4=lookup_widget(objet,"entry13");
input5=lookup_widget(objet,"entry17");

strcpy(r.des,gtk_combo_box_get_active_text(GTK_ENTRY(input1)));
strcpy(r.dep,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.he,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.arr,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.hee,gtk_entry_get_text(GTK_ENTRY(input5)));

gtk_label_set_text(GTK_LABEL(output),"Ajout validé :) ");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");
	gtk_entry_set_text(GTK_ENTRY(input4),"");
	gtk_entry_set_text(GTK_ENTRY(input5),"");
ajouter_reservation(r);




}


void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
Reclamation r;

GtkWidget *output,*input1,*input2;

output=lookup_widget(button,"label100");
input1=lookup_widget(button,"entry88");
input2=lookup_widget(button,"entry99");

strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.description,gtk_entry_get_text(GTK_ENTRY(input2)));

gtk_label_set_text(GTK_LABEL(output),"Reclamation envoyé avec succée :) ");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");

ajouter_reclamation(r);
}


void
on_button21_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window5;
GtkWidget *treeview1;

window5=lookup_widget(objet,"window5");


gtk_widget_destroy(window5);
window5 = create_window5();
gtk_widget_show(window5);
treeview1=lookup_widget(window5,"treeview1");
afficher_reservation(treeview1);
}


void
on_play_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.youtube.com/watch?v=OhRmq5D0rrI&fbclid=IwAR0mtJDrJKN0imUdWW913lQrBXDPVZDRAVSrnlodO-zmK-hETXNLMU4YHHg");
}


void
on_instagram_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.instagram.com/challenge/?next=/explore/tags/voyage/%253Fhl%253Dfr");
}


void
on_facebook_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.facebook.com/groups/OnAVoyagePourVous/");
}


void
on_twitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://twitter.com/voyageprive?lang=fr");
}


void
on_skytravel_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
system("eog abc.gif");
}

