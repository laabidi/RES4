#include <gtk/gtk.h>

typedef struct
{
char des[50];
char dep[50];
char he[20];
char arr[50];
char hee[20];
}reservation;

void ajouter_reservation( reservation r);


